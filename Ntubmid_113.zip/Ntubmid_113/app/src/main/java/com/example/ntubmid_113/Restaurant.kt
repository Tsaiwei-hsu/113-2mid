package com.example.ntubmid_113

data class Restaurant(
    var name: String,
    var phone: String
)
