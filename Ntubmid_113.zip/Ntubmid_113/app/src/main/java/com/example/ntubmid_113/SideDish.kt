package com.example.ntubmid_113

data class SideDish(
    val name: String,
    val price: String,
    val imageResId: Int,
    var quantity: Int = 0
)
